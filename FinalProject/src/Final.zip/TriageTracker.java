
/*
 * This work complies with the JMU honor code. I have not discussed this assignment with others. I
 * will not share information about my solution. I have not accessed resources outside of those
 * posted to the course Canvas page.
 * 
 * Signed: Ryan Gross
 */

public class TriageTracker  {

  public TriageTracker() {

  }

  public void addPatient(String id, int priority) {



  }

  public String nextPatient() {
    
    return null;
  }

  public void removePatient(String id) {


  }
  
 
  

}
